import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.UIManager;
import java.util.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {
	private JLabel heading;
	private JLabel background;
	private ImageIcon img;
	
	private JButton submit;
	private JButton goback;
	
	private JTextField userName;
	private JPasswordField password;
	
	private JLabel userLabel;
	private JLabel passLabel;
	
	private Container cp;
	
	public Login() {
		intializeComponents();
		registerListeners();
		addComponentsToFrame();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(540, 360);
		setVisible(true);
		setTitle("LOGIN PAGE");
	}
	
	public void intializeComponents() {
		cp = getContentPane();
		
		img = new ImageIcon("Login.jpg");
		
		background = new JLabel("", img, JLabel.CENTER);
		background.setBounds(0, 0, 540, 360);
		
		heading = new JLabel("SIGN IN");
		heading.setFont(new Font("Serif", Font.BOLD, 18));
		heading.setForeground(Color.RED);
		heading.setBounds(300, 15, 75, 30);
		
		userLabel = new JLabel("Enter your userID: ");
		userLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		userLabel.setForeground(Color.WHITE);
		userLabel.setBounds(200, 45, 200, 75);
		
		passLabel = new JLabel("Enter your password: ");
		passLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		passLabel.setForeground(Color.WHITE);
		passLabel.setBounds(200, 90, 200, 75);
		
		userName = new JTextField(15);
		userName.setBounds(400, 68, 100, 25);
		
		password = new JPasswordField(15);
		password.setBounds(400, 113, 100, 25);
		
		submit = new JButton("SUBMIT");
		submit.setBounds(225, 175, 100, 30);
		goback = new JButton("GOBACK");
		goback.setBounds(375, 175, 100, 30);
	}
	
	private void registerListeners() {
		submit.addActionListener(this);
		goback.addActionListener(this);
		
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch(Exception e) { 
            System.out.println("Look and Feel not set"); 
        }
	}

	private void addComponentsToFrame() {
		cp.add(background);
		background.add(heading);
		background.add(userLabel);
		background.add(userName);
		background.add(passLabel);
		background.add(password);
		background.add(submit);
		background.add(goback);
	}
	
	public void actionPerformed(ActionEvent ae) {
		String arg = ae.getActionCommand();
		if (arg.equals("GOBACK")) {
			dispose();
			new CustomerPage();
		}
		else if (arg.equals("SUBMIT")) {
			int flag = 0;
			String uname, pass;
			uname = userName.getText();
			pass = String.valueOf(password.getPassword());
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");  
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "rishik", "rishik");				
				Statement stmt = con.createStatement();  
				ResultSet rs = stmt.executeQuery("select customer_id, password from CUSTOMER");  
				while(rs.next())  {
					if ((uname.equals(rs.getString(1))) && (pass.equals(rs.getString(2)))) {
						JOptionPane.showMessageDialog(this, "LOGIN SUCCESSFUL", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
						flag = 1;
						dispose();
						new MoviePage();
					}
				}
				con.close();
				
				if (flag == 0)
					JOptionPane.showMessageDialog(this, "INCORRECT CREDENTIALS, TRY AGAIN!!", "WARNING", JOptionPane.WARNING_MESSAGE);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}