import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.UIManager;

public class CustomerPage extends JFrame implements ActionListener {
	private JLabel background;
	private ImageIcon img;
	
	private JButton register;
	private JButton login;
	private JButton goback;
	
	private Container cp;
	
	public CustomerPage() {
		cp = getContentPane();
		
		img = new ImageIcon("CustomerPage.jpg");
		
		background = new JLabel("", img, JLabel.CENTER);
		background.setBounds(0, 0, 738, 416);
		
		register = new JButton("REGISTER");
		register.setBounds(500, 160, 100, 25);
		login = new JButton("LOGIN");
		login.setBounds(500, 190, 100, 25);
		goback = new JButton("GOBACK");
		goback.setBounds(500, 220, 100, 25);
		
		register.addActionListener(this);
		login.addActionListener(this);
		goback.addActionListener(this);
		
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch(Exception e) { 
            System.out.println("Look and Feel not set"); 
        }
		
		cp.add(background);
		background.add(register);
		background.add(login);
		background.add(goback);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(738, 416);
		setVisible(true);
		setTitle("CUSTOMER PAGE");
	}
	
	public void actionPerformed(ActionEvent ae) {
		String arg = ae.getActionCommand();
		if (arg.equals("REGISTER")) {
			dispose();
			new Register();
		}
		else if (arg.equals("LOGIN")) {
			dispose();
			new Login();
		}
		else if (arg.equals("GOBACK")) {
			dispose();
			new HomePage();
		}
	}
}