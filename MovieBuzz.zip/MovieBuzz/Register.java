import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.UIManager;
import java.util.*;
import java.util.regex.*;
import java.math.*;
import java.sql.*;

public class Register extends JFrame implements ActionListener {
	private JLabel heading;
	private JLabel fmand;
	private JLabel background;
	private ImageIcon img;
	
	private JButton submit;
	private JButton reset;
	private JButton goback;
	
	private JTextField firstName;
	private JTextField lastName;
	private JPasswordField password;
	private JPasswordField confirmPassword;
	private JTextField phoneNumber;
	
	private JLabel fnLabel;
	private JLabel ast1;
	private JLabel lnLabel;
	private JLabel ast2;
	private JLabel passLabel;
	private JLabel ast3;
	private JLabel cpassLabel;
	private JLabel ast4;
	private JLabel pnLabel;
	private JLabel ast5;
	
	private Container cp;
	
	public Register() {
		intializeComponents();
		registerListeners();
		addComponentsToFrame();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1100, 732);
		setVisible(true);
		setTitle("REGISTRATION PAGE");
	}
	
	private void intializeComponents() {
		cp = getContentPane();
		
		img = new ImageIcon("Register.jpg");
		
		background = new JLabel("", img, JLabel.CENTER);
		background.setBounds(0, 0, 1100, 732);
		
		heading = new JLabel("SIGN UP");
		heading.setForeground(Color.BLUE);
		heading.setFont(new Font("Serif", Font.BOLD, 35));
		heading.setBounds(455, 15, 150, 25);
		
		fmand = new JLabel("(*) - ALL FIELDS ARE MANDATORY");
		fmand.setForeground(Color.RED);
		fmand.setFont(new Font("Serif", Font.BOLD, 18));
		fmand.setBounds(375, 45, 325, 25);
		
		fnLabel = new JLabel("Enter your first Name:");
		ast1 = new JLabel("*");
		fnLabel.setForeground(Color.BLACK);
		ast1.setForeground(Color.RED);
		fnLabel.setFont(new Font("Serif", Font.BOLD, 18));
		ast1.setFont(new Font("Serif", Font.BOLD, 18));
		fnLabel.setBounds(300, 90, 300, 25);
		ast1.setBounds(475, 93, 10, 25);
		
		firstName = new JTextField(15);
		firstName.setBounds(550, 90, 150, 25);
		
		lnLabel = new JLabel("Enter your last Name:");
		ast2 = new JLabel("*");
		lnLabel.setForeground(Color.BLACK);
		ast2.setForeground(Color.RED);
		lnLabel.setFont(new Font("Serif", Font.BOLD, 18));
		ast2.setFont(new Font("Serif", Font.BOLD, 18));
		lnLabel.setBounds(300, 140, 300, 25);
		ast2.setBounds(475, 143, 10, 25);
		
		lastName = new JTextField(15);
		lastName.setBounds(550, 140, 150, 25);
		
		passLabel = new JLabel("Enter your password:");
		ast3 = new JLabel("*");
		passLabel.setForeground(Color.BLACK);
		ast3.setForeground(Color.RED);
		passLabel.setFont(new Font("Serif", Font.BOLD, 18));
		ast3.setFont(new Font("Serif", Font.BOLD, 18));
		passLabel.setBounds(300, 190, 300, 25);
		ast3.setBounds(475, 193, 10, 25);
		
		password = new JPasswordField(15);
		password.setBounds(550, 190, 150, 25);
		
		cpassLabel = new JLabel("Re-enter passowrd:");
		ast4 = new JLabel("*");
		cpassLabel.setForeground(Color.BLACK);
		ast4.setForeground(Color.RED);
		cpassLabel.setFont(new Font("Serif", Font.BOLD, 18));
		ast4.setFont(new Font("Serif", Font.BOLD, 18));
		cpassLabel.setBounds(300, 240, 300, 25);
		ast4.setBounds(475, 243, 10, 25);
		
		confirmPassword = new JPasswordField(15);
		confirmPassword.setBounds(550, 240, 150, 25);
		
		pnLabel = new JLabel("Enter phone number:");
		ast5 = new JLabel("*");
		pnLabel.setForeground(Color.BLACK);
		ast5.setForeground(Color.RED);
		pnLabel.setFont(new Font("Serif", Font.BOLD, 18));
		ast5.setFont(new Font("Serif", Font.BOLD, 18));
		pnLabel.setBounds(300, 290, 300, 25);
		ast5.setBounds(475, 293, 10, 25);
		
		phoneNumber = new JTextField(15);
		phoneNumber.setBounds(550, 290, 150, 25);	
		
		goback = new JButton("GOBACK");
		goback.setBounds(300, 390, 100, 25);
		submit = new JButton("SUBMIT");
		submit.setBounds(450, 390, 100, 25);
		reset = new JButton("RESET");
		reset.setBounds(600, 390, 100, 25);
	}
	
	private void registerListeners() {
		submit.addActionListener(this);
		reset.addActionListener(this);
		goback.addActionListener(this);
		
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch(Exception e) { 
            System.out.println("Look and Feel not set"); 
        }
	}
	
	private void addComponentsToFrame() {
		cp.add(background);
		
		background.add(heading);
		background.add(fmand);
		background.add(fnLabel);
		background.add(ast1);
		background.add(firstName);
		background.add(lnLabel);
		background.add(ast2);
		background.add(lastName);
		background.add(passLabel);
		background.add(ast3);
		background.add(password);
		background.add(cpassLabel);
		background.add(ast4);
		background.add(confirmPassword);
		background.add(pnLabel);
		background.add(ast5);
		background.add(phoneNumber);
		background.add(goback);
		background.add(submit);
		background.add(reset);
	}
	
	public void actionPerformed(ActionEvent ae) {
		if (ae.getActionCommand().equals("GOBACK")) {
			dispose();
			new CustomerPage();
		}
		else if (ae.getActionCommand().equals("RESET")) {
			firstName.setText("");
			lastName.setText("");
			password.setText("");
			confirmPassword.setText("");
			phoneNumber.setText("");
		}
		else if (ae.getActionCommand().equals("SUBMIT")) {
			String name, pass, cpass;
			name = "";
			BigDecimal pn = null;
			
			try {
				pass = String.valueOf(password.getPassword());
				cpass = String.valueOf(confirmPassword.getPassword());
				if (!phoneNumber.getText().equals("")) 
					pn = new BigDecimal(phoneNumber.getText());	
				
				String fname = firstName.getText();
				fname = fname.replaceAll("( )+" , " ");
				fname = fname.trim();
				
				if ((name.equals(" ")) || (pass.equals("")) || (cpass.equals("")) || (phoneNumber.getText().equals(""))) {
					JOptionPane.showMessageDialog(this, "ENTER COMPLETE DETAILS", "ERROR", JOptionPane.ERROR_MESSAGE);					
				}
				else if ((fname.equals("")) || (fname.equals(null)) || (!fname.matches("^[a-zA-Z]+( [a-zA-z]+)*$"))) {
					JOptionPane.showMessageDialog(this, "FIRST NAME SHOULD BE ENTERED PROPERLY" + "\n" + "ALLOWED CHARACTERS ARE 'a-z' (or) 'A-Z'", "WARNING", JOptionPane.WARNING_MESSAGE);
				}
				else if ((lastName.getText().equals("")) || (lastName.getText() == null) || (!lastName.getText().matches("^[a-zA-Z]*$"))) {
					JOptionPane.showMessageDialog(this, "LAST NAME SHOULD BE ENTERED PROPERLY" + "\n" + "ALLOWED CHARACTERS ARE 'a-z' (or) 'A-Z'", "WARNING", JOptionPane.WARNING_MESSAGE);
				}	
				else if (String.valueOf(password.getPassword()).length() < 8) {
					JOptionPane.showMessageDialog(this, "PASSWORD SHOULD BE ATLEAST 8 CHARACTERS", "WARNING", JOptionPane.WARNING_MESSAGE);
				}
				else if (!pass.equals(cpass)) {
					JOptionPane.showMessageDialog(this, "ENTERED PASSWORD AND CONFIRMATION PASSWORD DIDN'T MATCHED", "WARNING", JOptionPane.WARNING_MESSAGE);
				}
				else if (phoneNumber.getText().length() != 10) {
					JOptionPane.showMessageDialog(this, "PHONE NUMBER MUST BE 10 DIGITS", "WARNING", JOptionPane.WARNING_MESSAGE);
				}
				else if (phoneNumber.getText().charAt(0) <= 53) {
					JOptionPane.showMessageDialog(this, "STARTING DIGIT OF THE PHONE NUMBER SHOULD BE 6, 7, 8 (or) 9", "WARNING", JOptionPane.WARNING_MESSAGE);
				}
				else {
					name = fname + " " + lastName.getText();
					String customerID = null;
					
					try {
						Class.forName("oracle.jdbc.driver.OracleDriver");  
						Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "rishik", "rishik");			
						Statement stmt = con.createStatement();  
						ResultSet rs = stmt.executeQuery("select count(*) from CUSTOMER");
						rs.next();
						
						customerID = "C-";
						int idNum = rs.getInt(1) + 1;
						if (idNum < 10)
							customerID = customerID + "0" + idNum;
						else
							customerID += idNum;
						
						PreparedStatement psmt = con.prepareStatement("insert into CUSTOMER values(?, ?, ?, ?)");
						psmt.setString(1, customerID);
						psmt.setString(2, name);
						psmt.setString(3, pass);
						psmt.setBigDecimal(4, pn);
						
						psmt.executeUpdate();
						
						String msg = ("DETAILS OF THE CUSTOMER" + "\n" +
									  "Customer's Name: " + name + "\n" +
									  "Customer's Password: " + pass + "\n" +
									  "Customer's Phone Number: " + pn + "\n" +
									  "CUSTOMER ID: " + customerID);
						JOptionPane.showMessageDialog(this, msg, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);							
						con.close();
					}
					catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(this, "PHONE NUMBER SHOULD NOT CONTAIN ANY ALPHABETS", "WARNING", JOptionPane.WARNING_MESSAGE);
			}
			catch (NullPointerException e) {
				JOptionPane.showMessageDialog(this, "FIRST NAME SHOULD NOT BE EMPTY" + "\n" + "ALLOWED CHARACTERS ARE 'a-z' (or) 'A-Z'", "WARNING", JOptionPane.WARNING_MESSAGE);
			}
		}
	}
}