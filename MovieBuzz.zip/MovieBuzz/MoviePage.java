import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.UIManager;

public class MoviePage extends JFrame implements ActionListener {
	private JLabel background;
	private ImageIcon img;
	
	private JLabel heading;
	
	private JButton next;
	private JButton goback;
	
	private Container cp;
	
	public MoviePage() {
		cp = getContentPane();
		
		img = new ImageIcon("MoviePage.jpg");
		
		background = new JLabel("", img, JLabel.CENTER);
		background.setBounds(0, 0, 609, 405);
		
		next = new JButton("CONTINUE");
		next.setBounds(255, 330, 100, 25);
		
		goback = new JButton("GOBACK");
		goback.setBounds(260, 300, 85, 25);
		
		next.addActionListener(this);
		goback.addActionListener(this);

		cp.add(background);
		background.add(next);
		background.add(goback);
		
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch(Exception e) { 
            System.out.println("Look and Feel not set"); 
        }
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(609, 405);
		setVisible(true);
		setTitle("MOVIE PAGE");
	}
	
	public void actionPerformed(ActionEvent ae) {
		String arg = ae.getActionCommand();
		if (arg.equals("CONTINUE")) {
			dispose();
		}
		else if (arg.equals("GOBACK")) {
			dispose();
			new CustomerPage();
		}
	}
}