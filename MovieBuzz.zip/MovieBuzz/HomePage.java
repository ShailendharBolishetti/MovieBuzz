import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.UIManager;

public class HomePage extends JFrame implements ActionListener {
	private JLabel background;
	private ImageIcon img;
	
	private JButton customer;
	private JButton admin;
	
	private JMenuBar mbr;
	private JMenu file;
	private JMenuItem about;
	private JMenuItem credentials;
	private JMenuItem quit;
	
	private Container cp;
	
	public HomePage() {
		cp = getContentPane();
		
		img = new ImageIcon("HomePage.jpg");
		
		background = new JLabel("", img, JLabel.CENTER);
		background.setBounds(0, 0, 654, 469);
		
		customer = new JButton("CUSTOMER");
		customer.setBounds(180, 270, 100, 25);
		admin = new JButton("ADMIN");
		admin.setBounds(359, 270, 100, 25);
		
		mbr = new JMenuBar();
		setJMenuBar(mbr);
		
		file = new JMenu("FILE");
		mbr.add(file);
		file.add(about = new JMenuItem("About"));
		file.add(credentials = new JMenuItem("Credentials"));
		file.add("-------------------------");
		file.add(quit = new JMenuItem("Quit"));
		
		customer.addActionListener(this);
		admin.addActionListener(this);
		about.addActionListener(this);
		credentials.addActionListener(this);
		quit.addActionListener(this);
		
		
		cp.add(background);
		background.add(customer);
		background.add(admin);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(654, 469);
		setVisible(true);
		setTitle("HOME PAGE");
	}
	
	public void actionPerformed(ActionEvent ae) {
		String arg = ae.getActionCommand();
		if (arg.equals("About")) {
			String projectInfo = ("MOVIEBUZZ is a Desktop application for booking cinema tickets." + "\n" +
			                      "The objective of MOVIEBUZZ is to create an application for Movie ticket " + "\n" +
								  "booking that allows users to know about new movies, cinema locations, " + "\n" +
								  "available theatres, their schedules, class, and ticket price." + "\n" + "\n" +
                                  "                                              THANK YOU!!");
			JOptionPane.showMessageDialog(this, projectInfo, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
		}
		else if (arg.equals("Credentials")) {
			String credentialsInfo = ("Name: V. Rishik, ROLL NO: 1602-19-737-156, Section: IT-C" + "\n" +
									  "Name: K. Rithik, ROLL NO: 1602-19-737-157, Section: IT-C" + "\n" +
									  "Name: B. Shailendhar, ROLL NO: 1602-19-737-167, Section: IT-C" + "\n");
			JOptionPane.showMessageDialog(this, credentialsInfo, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
		}
		else if (arg.equals("Quit")) {
			System.exit(0);
		}
		else if (arg.equals("CUSTOMER")) {
			dispose();
			new CustomerPage();
		}
		else if (ae.getActionCommand().equals("ADMIN")) {
			dispose();
			new AdminLogin();
		}
	}
	
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch(Exception e) { 
            System.out.println("Look and Feel not set"); 
        }
		
		new HomePage();
	}
}