import java.awt.*;
import java.awt.event.*;
import java.awt.print.*;
import javax.swing.*;
import javax.swing.UIManager;
import java.sql.*;

public class AdminView extends JFrame implements ActionListener {
	private JLabel heading;
	private JLabel background;
	private ImageIcon img;
	
	private JLabel tList;
	
	private Choice cmovie;
	
	private JButton viewTable;
	private JButton goback;
	
	private JTable table;
	
	private JScrollPane scrollPane;
	
	private Container cp;
	
	public AdminView() {
		intializeComponents();
		registerListeners();
		addComponentsToFrame();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(612, 382);
		setVisible(true);
		setTitle("VIEW TABLES");
	}
	
	public void intializeComponents() {
		cp = getContentPane();
		
		img = new ImageIcon("AdminView.jpg");
		
		background = new JLabel("", img, JLabel.CENTER);
		background.setBounds(0, 0, 612, 382);
		
		heading = new JLabel("VIEW TABLES");
		heading.setFont(new Font("Serif", Font.BOLD, 25));
		heading.setForeground(Color.RED);
		heading.setBounds(185, 15, 225, 30);
		
		tList = new JLabel("TABLES LIST");
		tList.setFont(new Font("Serif", Font.BOLD, 20));
		tList.setForeground(Color.BLUE);
		tList.setBounds(415, 15, 225, 30);		
		
		cmovie = new Choice();
		cmovie.add("CUSTOMER");
		cmovie.add("BOOKINGS");
		cmovie.add("MOVIE_DETAILS");
		cmovie.add("MOVIE_TIMINGS");
		cmovie.add("THEATRE");
		cmovie.add("SHOWS");
		cmovie.add("SCREEN");
		cmovie.add("TICKETS");
		cmovie.setBounds(400, 50, 150, 25);
		
		viewTable = new JButton("VIEW TABLE");
		viewTable.setBounds(400, 200, 125, 25);
		
		goback = new JButton("GOBACK");
		goback.setBounds(415, 250, 100, 25);
	}
	
	public void registerListeners() {
		viewTable.addActionListener(this);
		goback.addActionListener(this);
		
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch(Exception e) { 
            System.out.println("Look and Feel not set"); 
        }
	}
	
	public void addComponentsToFrame() {
		cp.add(background);
		background.add(heading);
		background.add(cmovie);
		background.add(tList);
		background.add(viewTable);
		background.add(goback);		
	}
	
	public void actionPerformed(ActionEvent ae) {
		String arg = ae.getActionCommand();
		if (arg.equals("GOBACK")) {
			dispose();
			new AdminLogin();
		}
		else if (arg.equals("VIEW TABLE")) {
			String s = cmovie.getItem(cmovie.getSelectedIndex());
			Object[][] rows;
			JFrame vTabel;
			int index = 0, totalRows;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");  
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "rishik", "rishik");				
				Statement stmt = con.createStatement();  
				
				if (s.equals("CUSTOMER")) {
					ResultSet rs = stmt.executeQuery("select count(*) from CUSTOMER");
					rs.next();
					totalRows = rs.getInt(1);					
					
					Object[] columns = {"CustomerID", "CustomerName", "Password", "PhoneNumber"};
					rs = stmt.executeQuery("select * from CUSTOMER");
					rows = new Object[totalRows][columns.length];
					
					while (index < totalRows) {
						rs.next();
						rows[index][0] = rs.getString(1);
						rows[index][1] = rs.getString(2);
						rows[index][2] = rs.getString(3);
						rows[index][3] = rs.getString(4);
						
						index += 1;
					}
					
					table = new JTable(rows, columns);
					scrollPane = new JScrollPane(table);
					
					vTabel = new JFrame("CUSTOMER TABLE");
					vTabel.add(scrollPane, "Center");
					vTabel.setVisible(true);
					vTabel.setSize(650, 250);
				}
				else if (s.equals("BOOKINGS")) {
					ResultSet rs = stmt.executeQuery("select count(*) from BOOKINGS");
					rs.next();
					totalRows = rs.getInt(1);					
					
					Object[] columns = {"BookingID", "CustomerID", "BookingDate", "MovieDate", "TicketID"};
					rs = stmt.executeQuery("select * from BOOKINGS");
					rows = new Object[totalRows][columns.length];
					
					while (index < totalRows) {
						rs.next();
						rows[index][0] = rs.getString(1);
						rows[index][1] = rs.getString(2);
						rows[index][2] = rs.getDate(3);
						rows[index][3] = rs.getDate(4);
						rows[index][4] = rs.getString(5);
						
						index += 1;
					}
					
					table = new JTable(rows, columns);
					scrollPane = new JScrollPane(table);
					
					vTabel = new JFrame("BOOKINGS TABLE");
					vTabel.add(scrollPane, "Center");
					vTabel.setVisible(true);
					vTabel.setSize(650, 250);
				}
				else if (s.equals("MOVIE_DETAILS")) {
					ResultSet rs = stmt.executeQuery("select count(*) from MOVIE_DETAILS");
					rs.next();
					totalRows = rs.getInt(1);					
					
					Object[] columns = {"MovieID", "MovieName", "Language", "Duration"};
					rs = stmt.executeQuery("select * from MOVIE_DETAILS");
					rows = new Object[totalRows][columns.length];
					
					while (index < totalRows) {
						rs.next();
						rows[index][0] = rs.getString(1);
						rows[index][1] = rs.getString(2);
						rows[index][2] = rs.getString(3);
						rows[index][3] = rs.getString(4);
						
						index += 1;
					}
					
					table = new JTable(rows, columns);
					scrollPane = new JScrollPane(table);
					
					vTabel = new JFrame("MOVIE_DETAILS TABLE");
					vTabel.add(scrollPane, "Center");
					vTabel.setVisible(true);
					vTabel.setSize(650, 250);
				}
				else if (s.equals("MOVIE_TIMINGS")) {
					ResultSet rs = stmt.executeQuery("select count(*) from MOVIE_TIMINGS");
					rs.next();
					totalRows = rs.getInt(1);
					
					Object[] columns = {"MovieID", "StartTime", "EndTime"};
					rs = stmt.executeQuery("select * from MOVIE_TIMINGS");
					rows = new Object[totalRows][columns.length];
					
					while (index < totalRows) {
						rs.next();
						rows[index][0] = rs.getString(1);
						rows[index][1] = rs.getString(2);
						rows[index][2] = rs.getString(3);
						
						index += 1;
					}
					
					table = new JTable(rows, columns);
					scrollPane = new JScrollPane(table);
					
					vTabel = new JFrame("MOVIE_TIMINGS TABLE");
					vTabel.add(scrollPane, "Center");
					vTabel.setVisible(true);
					vTabel.setSize(500, 250);
				}
				else if (s.equals("THEATRE")) {
					ResultSet rs = stmt.executeQuery("select count(*) from THEATRE");
					rs.next();
					totalRows = rs.getInt(1);
					
					Object[] columns = {"TheatreID", "TheatreName", "Location", "NoOfScreens"};
					rs = stmt.executeQuery("select * from THEATRE");
					rows = new Object[totalRows][columns.length];
					
					while (index < totalRows) {
						rs.next();
						rows[index][0] = rs.getString(1);
						rows[index][1] = rs.getString(2);
						rows[index][2] = rs.getString(3);
						rows[index][3] = rs.getString(4);
						
						index += 1;
					}
					
					table = new JTable(rows, columns);
					scrollPane = new JScrollPane(table);
					
					vTabel = new JFrame("THEATRE TABLE");
					vTabel.add(scrollPane, "Center");
					vTabel.setVisible(true);
					vTabel.setSize(500, 250);
				}
				else if (s.equals("SHOWS")) {
					ResultSet rs = stmt.executeQuery("select count(*) from SHOWS");
					rs.next();
					totalRows = rs.getInt(1);
					
					Object[] columns = {"TheatreID", "MovieID"};
					rs = stmt.executeQuery("select * from SHOWS");
					rows = new Object[totalRows][columns.length];
					
					while (index < totalRows) {
						rs.next();
						rows[index][0] = rs.getString(1);
						rows[index][1] = rs.getString(2);
						
						index += 1;
					}
					
					table = new JTable(rows, columns);
					scrollPane = new JScrollPane(table);
					
					vTabel = new JFrame("SHOWS TABLE");
					vTabel.add(scrollPane, "Center");
					vTabel.setVisible(true);
					vTabel.setSize(500, 250);
				}
				else if (s.equals("SCREEN")) {
					ResultSet rs = stmt.executeQuery("select count(*) from SCREEN");
					rs.next();
					totalRows = rs.getInt(1);
					
					Object[] columns = {"ScreenID", "TheatreID", "NoOfSeats"};
					rs = stmt.executeQuery("select * from SCREEN");
					rows = new Object[totalRows][columns.length];
					
					while (index < totalRows) {
						rs.next();
						rows[index][0] = rs.getString(1);
						rows[index][1] = rs.getString(2);
						rows[index][2] = rs.getString(3);						
						
						index += 1;
					}
					
					table = new JTable(rows, columns);
					scrollPane = new JScrollPane(table);
					
					vTabel = new JFrame("SCREEN TABLE");
					vTabel.add(scrollPane, "Center");
					vTabel.setVisible(true);
					vTabel.setSize(650, 250);
				}
				else if (s.equals("TICKETS")) {
					ResultSet rs = stmt.executeQuery("select count(*) from TICKETS");
					rs.next();
					totalRows = rs.getInt(1);
					
					Object[] columns = {"TicketID", "CustomerID", "AdminID", "MovieID", "StartTime", "EndTime", "TheatreID", "ScreenID", "SeatNo", "Price"};
					rs = stmt.executeQuery("select * from TICKETS");
					rows = new Object[totalRows][columns.length];
					
					while (index < totalRows) {
						rs.next();
						rows[index][0] = rs.getString(1);
						rows[index][1] = rs.getString(2);
						rows[index][2] = rs.getString(3);
						rows[index][3] = rs.getString(4);
						rows[index][4] = rs.getString(5);
						rows[index][5] = rs.getString(6);
						rows[index][6] = rs.getString(7);
						rows[index][7] = rs.getString(8);
						rows[index][8] = rs.getString(9);
						rows[index][9] = rs.getString(10);						
						
						index += 1;
					}
					
					table = new JTable(rows, columns);
					scrollPane = new JScrollPane(table);
					
					vTabel = new JFrame("TICKETS TABLE");
					vTabel.add(scrollPane, "Center");
					vTabel.setVisible(true);
					vTabel.setSize(1000, 500);
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}