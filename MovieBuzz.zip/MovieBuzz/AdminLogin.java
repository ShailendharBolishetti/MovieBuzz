import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.UIManager;
import java.util.*;
import java.sql.*;

public class AdminLogin extends JFrame implements ActionListener {
	private JLabel heading;
	private JLabel background;
	private ImageIcon img;
	
	private JButton submit;
	private JButton goback;
	
	private JTextField userName;
	private JPasswordField password;
	
	private JLabel userLabel;
	private JLabel passLabel;
	
	private JMenuBar mbr;
	private JMenu file;
	private JMenuItem about;
	private JMenuItem credentials;
	
	private Container cp;
	
	public AdminLogin() {
		intializeComponents();
		registerListeners();
		addComponentsToFrame();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(612, 408);
		setVisible(true);
		setTitle("ADMIN PAGE");
	}
	
	public void intializeComponents() {
		cp = getContentPane();
		
		img = new ImageIcon("AdminLogin.jpg");
		
		background = new JLabel("", img, JLabel.CENTER);
		background.setBounds(0, 0, 612, 408);
		
		mbr = new JMenuBar();
		setJMenuBar(mbr);
		
		file = new JMenu("FILE");
		mbr.add(file);
		file.add(about = new JMenuItem("About"));
		file.add(credentials = new JMenuItem("Credentials"));
		
		heading = new JLabel("ADMIN SIGN IN");
		heading.setFont(new Font("Serif", Font.BOLD, 25));
		heading.setForeground(Color.RED);
		heading.setBounds(185, 15, 225, 30);
		
		userLabel = new JLabel("Enter your userID: ");
		userLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		userLabel.setForeground(Color.BLACK);
		userLabel.setBounds(125, 45, 200, 75);
		
		passLabel = new JLabel("Enter your password: ");
		passLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		passLabel.setForeground(Color.BLACK);
		passLabel.setBounds(105, 90, 200, 75);
		
		userName = new JTextField(15);
		userName.setBounds(300, 70, 125, 25);
		
		password = new JPasswordField(15);
		password.setBounds(300, 115, 125, 25);
		
		submit = new JButton("SUBMIT");
		submit.setBounds(125, 200, 100, 30);
		goback = new JButton("GOBACK");
		goback.setBounds(300, 200, 100, 30);
	}
	
	private void registerListeners() {
		submit.addActionListener(this);
		goback.addActionListener(this);
		about.addActionListener(this);
		credentials.addActionListener(this);
		
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch(Exception e) { 
            System.out.println("Look and Feel not set"); 
        }
	}

	private void addComponentsToFrame() {
		cp.add(background);
		background.add(heading);
		background.add(userLabel);
		background.add(userName);
		background.add(passLabel);
		background.add(password);
		background.add(submit);
		background.add(goback);
	}
	
	public void actionPerformed(ActionEvent ae) {
		String arg = ae.getActionCommand();
		if (arg.equals("About")) {
			String msg = ("Admin is the special USER in MOVIEBUZZ." + "\n" +
			              "Admin can view all the details about theatres, " + "\n" +
						  "movies and majorly can view all the customers " + "\n" + 
						  "and their respective bookings.");
			JOptionPane.showMessageDialog(this, msg, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
		}	
		else if (arg.equals("Credentials")) {
			String msg = ("Username: System" + "\n" +
			              "Password: IT-156-157-167");
			JOptionPane.showMessageDialog(this, msg, "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
		}
		else if (arg.equals("SUBMIT")) {
			int flag = 0;
			String uname, pass;
			uname = userName.getText();
			pass = String.valueOf(password.getPassword());
			
			if ((uname.equalsIgnoreCase("System")) && (pass.equals("IT-156-157-167"))) {
				JOptionPane.showMessageDialog(this, "LOGIN SUCCESSFUL", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
				dispose();
				new AdminView();
			}
			else {
				JOptionPane.showMessageDialog(this, "INCORRECT CREDENTIALS, TRY AGAIN!!", "WARNING", JOptionPane.WARNING_MESSAGE);				
			}
		}
		else if (arg.equals("GOBACK")) {
			dispose();
			new HomePage();
		}
	}
}