import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.UIManager;
import java.sql.*;

public class MovieSelection extends JFrame implements ActionListener {
	private JLabel background;
	private ImageIcon img;
	
	private JLabel heading;
	
	private Choice cmovie;
	
	private JButton show;
	private JButton goback;
	
	private JTable table;
	
	private JScrollPane scrollPane;
	
	private Container cp;
	
	public MovieSelection() {
		intializeComponents();
		registerListeners();
		addComponentsToFrame();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(960, 350);
		setVisible(true);
		setTitle("MOVIE SELECTION PAGE");
	}
	
	public void intializeComponents() {
		cp = getContentPane();
		
		img = new ImageIcon("MovieSelection.jpg");
		
		background = new JLabel("", img, JLabel.CENTER);
		background.setBounds(0, 0, 960, 350);
		
		heading = new JLabel("MOVIE SELECTION");
		heading.setFont(new Font("Serif", Font.BOLD, 22));
		heading.setForeground(Color.RED);
		heading.setBounds(350, 50, 225, 30);
		
		cmovie = new Choice();
		cmovie.add("BLACK WIDOW");
		cmovie.add("Spider Man: NO WAY HOME");
		cmovie.add("K.G.F Chapter 2");
		cmovie.add("Jersy");
		cmovie.add("RRR");
		cmovie.setBounds(375, 90, 175, 25);
		
		show = new JButton("SHOW");
		show.setBounds(500, 200, 75, 25);
		goback = new JButton("GOBACK");
		goback.setBounds(300, 200, 100, 25);
	}
	
	private void registerListeners() {
		show.addActionListener(this);
		goback.addActionListener(this);
		
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } 
        catch(Exception e) { 
            System.out.println("Look and Feel not set"); 
        }
	}
	
	private void addComponentsToFrame() {
		cp.add(background);
		background.add(heading);
		background.add(cmovie);
		background.add(show);
		background.add(goback);
	}
	
	public void actionPerformed(ActionEvent ae) {
		String arg = ae.getActionCommand();
		if (arg.equals("GOBACK")) {
			dispose();
			new MoviePage();
		}
		else if (arg.equals("SHOW")) {
			String mname = cmovie.getItem(cmovie.getSelectedIndex());
			
			Object[][] rows = null;
			Object[] columns = {"TheatreID", "TheatreName", "Location", "NoOfScreens"};
			
			JFrame vTabel;
			JLabel mLabel;
			JTextField movie;
			
			int totalRows = 0, index = 0;
			
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver"); 
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "rishik", "rishik");				
				Statement stmt = con.createStatement();  
				ResultSet rs = null;
				
				if (mname.equals("BLACK WIDOW")) {
					rs = stmt.executeQuery("select count(*) from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'BLACK WIDOW' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rs.next();
					totalRows = rs.getInt(1);
				
					rs = stmt.executeQuery("select T.theatre_id, T.theatre_name, T.location, T.NoOfScreens from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'BLACK WIDOW' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rows = new Object[totalRows][columns.length];
				}
				else if (mname.equals("Spider Man: NO WAY HOME")) {
					rs = stmt.executeQuery("select count(*) from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'Spider Man: NO WAY HOME' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rs.next();
					totalRows = rs.getInt(1);
				
					rs = stmt.executeQuery("select T.theatre_id, T.theatre_name, T.location, T.NoOfScreens from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'Spider Man: NO WAY HOME' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rows = new Object[totalRows][columns.length];
				}
				else if (mname.equals("K.G.F Chapter 2")) {
					rs = stmt.executeQuery("select count(*) from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'K.G.F Chapter 2' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rs.next();
					totalRows = rs.getInt(1);
				
					rs = stmt.executeQuery("select T.theatre_id, T.theatre_name, T.location, T.NoOfScreens from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'K.G.F Chapter 2' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rows = new Object[totalRows][columns.length];
				}
				else if (mname.equals("Jersy")) {
					rs = stmt.executeQuery("select count(*) from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'Jersy' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rs.next();
					totalRows = rs.getInt(1);
				
					rs = stmt.executeQuery("select T.theatre_id, T.theatre_name, T.location, T.NoOfScreens from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'Jersy' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rows = new Object[totalRows][columns.length];
				}
				if (mname.equals("RRR")) {
					rs = stmt.executeQuery("select count(*) from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'RRR' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rs.next();
					totalRows = rs.getInt(1);
				
					rs = stmt.executeQuery("select T.theatre_id, T.theatre_name, T.location, T.NoOfScreens from THEATRE T, MOVIE_DETAILS MD, SHOWS S where MD.movie_name = 'RRR' and S.movie_id = MD.movie_id and T.theatre_id = S.theatre_id");
					rows = new Object[totalRows][columns.length];
				}
				
				while (index < totalRows) {
					rs.next();
					rows[index][0] = rs.getString(1);
					rows[index][1] = rs.getString(2);
					rows[index][2] = rs.getString(3);
					rows[index][3] = rs.getInt(4);
						
					index += 1;
				}
				
				table = new JTable(rows, columns);
				scrollPane = new JScrollPane(table);
					
				vTabel = new JFrame("LIST OF THEATRES");
				vTabel.add(scrollPane, "Center");
				vTabel.setVisible(true);
				vTabel.setSize(500, 250);
				
				con.close();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		new MovieSelection();
	}
}